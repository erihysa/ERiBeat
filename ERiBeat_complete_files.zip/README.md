# ERIBeat — replacement files

This bundle contains the full replacement files for:
- `pubspec.yaml`
- `lib/main.dart`
- `android/app/src/main/AndroidManifest.xml`

## Features
- Search audio files in Wikimedia Commons.
- Plays direct audio URLs returned by Commons.
- Playlist with play/pause, previous/next, seek, shuffle, repeat.
- Android background playback and lock-screen/notification controls through `just_audio_background`.
- Displays the artist and license label when Commons metadata provides it.

## Important
Wikimedia Commons hosts freely licensed/public-domain media, but individual files can have attribution or other license conditions. Check each file's source page before reuse. Search results depend on internet availability and on supported audio formats. This is not a commercial catalog like Spotify and it does not include copyrighted mainstream songs unless those are legitimately available there.

## Install into the existing GitHub repository
Replace the three files above with the versions in this bundle. Keep the existing GitHub Actions workflow. Then open Actions and run the Flutter APK build workflow.

The Android manifest uses `AudioServiceActivity` as required by `just_audio_background`.
